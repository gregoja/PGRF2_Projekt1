package geometryObject;

import model.Part;
import model.Solid;
import model.TypeTopology;
import model.Vertex;
import transforms.Point3D;

public class TetraHedron extends Solid {

     // vyrobit axises?
    // vertex,?
    // dopsat image buffer - nějaký podobně chytrý konstruktor, který ten buffered image předá...
    // jak by měl být objektový návrh té funkcionality rendererLine, renderer Trinagle...

    public TetraHedron() {
        getVertexBuffer().add(new Vertex(new Point3D()));
        getVertexBuffer().add(new Vertex(new Point3D()));
        getVertexBuffer().add(new Vertex(new Point3D()));
        getVertexBuffer().add(new Vertex(new Point3D()));

        getPartBuffer().add(new Part(TypeTopology.TRIANGLES,4,0));

        getIndexBuffer().add(0);
        getIndexBuffer().add(1);
        getIndexBuffer().add(2);

        getIndexBuffer().add(0);
        getIndexBuffer().add(1);
        getIndexBuffer().add(3);

        getIndexBuffer().add(0);
        getIndexBuffer().add(2);
        getIndexBuffer().add(3);

        getIndexBuffer().add(1);
        getIndexBuffer().add(2);  
        getIndexBuffer().add(3);
    }
}