package model;

import transforms.Mat4;
import transforms.Point3D;

public class Vertex {
    private final Point3D position;

    public Vertex(Point3D position) {
        this.position = position;
    }                                                                                                               

    // výzva do příště
    public Point3D transform(Mat4 transform){

    }
}
