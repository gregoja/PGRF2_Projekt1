package renderOperation;

import model.Vertex;
import rasterOperation.Visibility;
import transforms.Col;
import transforms.Point3D;

import java.util.function.Function;

public class Rasterizer {
    private Visibility visibility;
    private Function<Vertex,Col> shader;

    public Rasterizer(Visibility visibility, Function<Vertex, Col> shader) {
        this.visibility = visibility;
        /*this.shader = shader;*/
        this.shader = shader;
    }

    public void rasterizeTriangle(Vertex a, Vertex b, Vertex c) {
        a = a.dehomog();
        b = b.dehomog();
        c = c.dehomog();

        a = transformToWindow(a);
        b = transformToWindow(b);
        c = transformToWindow(c);

        Vertex temp;
        if (a.getPosition().getY() > b.getPosition().getY()) {
            temp = a;
            a = b;
            b = temp;
        }
        if (b.getPosition().getY() > c.getPosition().getY()) {
            temp = b;
            b = c;
            c = temp;
        }
        if (a.getPosition().getY() > b.getPosition().getY()) {
            temp = a;
            a = b;
            b = temp;
        }

        //final double xa = a.getPosition().getX();
        final double ya = a.getPosition().getY();

        //final double xb = b.getPosition().getX();
        final double yb = b.getPosition().getY();

        //final double xc = c.getPosition().getX();
        final double yc = c.getPosition().getY();

        for (int y = Math.max((int) ya + 1, 0); y < Math.min(yb, visibility.getHeight() - 1); y++) {
            double t1 = (y - ya) / (yb - ya);
            //double x1 = xa * (1 - t1) + t1 * xb;
            Vertex ab = a.mul(1 - t1).add(b.mul(t1));

            double t2 = (y - ya) / (yc - ya);
            //double x2 = xa * (1 - t2) + t2 * xc;
            Vertex ac = a.mul(1 - t2).add(c.mul(t2));

            drawScanLine(y, ab, ac);
        }

        for (int y = Math.max((int) yb + 1, 0); y < Math.min(yc, visibility.getHeight() - 1); y++) {
            double t1 = (y - yb) / (yc - yb);
            //double x1 = xb * (1 - t1) + t1 * xc;
            Vertex bc = b.mul(1 - t1).add(c.mul(t1));

            double t2 = (y - ya) / (yc - ya);
            //double x2 = xa * (1 - t2) + t2 * xc;
            Vertex ac = a.mul(1 - t2).add(c.mul(t2));

            drawScanLine(y, bc, ac);
        }
    }

    
    private void drawScanLine(int y, Vertex a, Vertex b) {

        if (a.getPosition().getX() > b.getPosition().getX()) {
            Vertex temp = a;
            a = b;
            b = temp;
        }

        final double x1 = a.getPosition().getX();
        final double x2 = b.getPosition().getX();

        for (int x = Math.max((int) x1 + 1, 0); x < Math.min(x2, visibility.getWidth() - 1); x++) {
            double s = (x - x1) / (x2 - x1);
            Vertex abc = a.mul(1 - s).add(b.mul(s));
            double z = abc.getPosition().getZ();
            int color = abc.getColor().getRGB();
            drawColorPixel(x,y,abc);
            //visibility.drawPixel(x, y, (float) z, color);
        }
    }

    private void drawColorPixel(int x, int y, Vertex abc) {
        //int color = abc.getColor().getRGB();
        int color = shader.apply(abc).getRGB();
        visibility.drawPixel(x,y,(float)abc.getPosition().getZ(),color);
    }

    private Vertex transformToWindow(Vertex v) {
        double x = (((v.getPosition().getX() + 1) / 2) * visibility.getWidth() - 1);
        double y = (((-v.getPosition().getY() + 1) / 2) * visibility.getHeight() - 1);
        return new Vertex(new Point3D(x, y, v.getPosition().getZ()), v.getColor(),v.getUv());
    }
}