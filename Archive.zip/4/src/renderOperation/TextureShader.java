package renderOperation;

import model.Vertex;
import transforms.Col;
import transforms.Vec2D;

public class TextureShader implements Shader {
    // konstruktor s referencí na tu texturu...

    @Override
    public Col getColor(Vertex v) {
        if ((int)(v.getUv().getX() *10)%2 == 0){
            return new Col(1.,0,0);
        }
        return null;
    }
}
