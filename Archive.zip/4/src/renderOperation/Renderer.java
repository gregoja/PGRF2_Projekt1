package renderOperation;

import model.Part;
import model.Solid;
import model.Vertex;
import rasterOperation.Visibility;
import transforms.Col;
import transforms.Mat4;
import transforms.Mat4Identity;
import transforms.Point3D;

import java.util.List;
import java.util.function.Function;

public class Renderer {
    private Mat4 view;
    private Mat4 projection;

    private Rasterizer rasterizer;

    public Renderer(Mat4 view, Mat4 projection, Visibility v) {
        this.view = view;
        this.projection = projection;
        //this.rasterizer = new Rasterizer(v,new TextureShader());
        /*this.rasterizer = new Rasterizer(v, new Shader() {
            @Override
            public Col getColor(Vertex v) {
                return new Col(1,1,1);
            }
        });*/
        /*this.rasterizer = new Rasterizer(v, (Vertex v1) -> {
            return new Col(1.,1,1);
        });*/
        /*this.rasterizer = new Rasterizer(v, v1-> new Col(1.,1,1));*/
        /*this.rasterizer = new Rasterizer(v, v1->v1.getColor());*/
        Function<Vertex, Col> sh = new Function<Vertex,Col>(){

            @Override
            public Col apply(Vertex vertex) {
                return null;
            }
        };
    }

    public void render(List<Solid> scene){
        for (Solid solid: scene) {
            render(solid);
        }
    }
    public void render(Solid solid){
        Mat4 mvp = solid.getTransforms().mul(view).mul(projection);
        for (Part part : solid.getPartBuffer()) {
            switch (part.getType()){
                case TRIANGLES: {
                    for(int i = 0; i < part.getCount(); i++){
                        Vertex a = solid.getVertexBuffer().get(solid.getIndexBuffer().get(3 * i + part.getStartIndex()));
                        Vertex b = solid.getVertexBuffer().get(solid.getIndexBuffer().get(3 * i + part.getStartIndex() + 1));
                        Vertex c = solid.getVertexBuffer().get(solid.getIndexBuffer().get(3 * i + part.getStartIndex() + 2));

                        drawTriangle(a,b,c,mvp);
                    }
                    break;
                }
                case TRIANGLE_STRIP:{
                    for (int i = 0; i < part.getCount(); i++) {
                        Vertex a = solid.getVertexBuffer().get(solid.getIndexBuffer().get(i));
                        Vertex b = solid.getVertexBuffer().get(solid.getIndexBuffer().get(i+1));
                        Vertex c = solid.getVertexBuffer().get(solid.getIndexBuffer().get(i+2));

                        drawTriangle(a,b,c,mvp);
                    }
                }
                //default: throw new java.lang.UnsupportedOperationException("Not supported yet.");
            }
        }
    }

    private void drawTriangle(Vertex a, Vertex b, Vertex c,Mat4 mvp){
        mvp = new Mat4Identity();
        /*a = new Vertex(a.transform(mvp),a.getColor());
        b = new Vertex(b.transform(mvp),b.getColor());
        c = new Vertex(c.transform(mvp),c.getColor());*/

        Point3D pa = a.getPosition();Point3D pb = b.getPosition();Point3D pc = c.getPosition();
        if (pa.getX() > pa.getW() && pb.getX() > pb.getW() && pc.getX() > pc.getW()) return;
        if (-pa.getW() > pa.getX() && -pb.getW() > pb.getX() && -pc.getW() > pc.getX()) return;
        if (pa.getY() > pa.getW() && pb.getY() > pb.getW() && pc.getY() > pc.getW()) return;
        if (-pa.getW() > pa.getY() && -pb.getW() > pb.getY() && -pc.getW() > pc.getY()) return;
        if (pa.getZ() > pa.getW() && pb.getZ() > pb.getW() && pc.getZ() > pc.getW()) return;
        if (pa.getZ() < 0 && pb.getZ() < 0 && pc.getZ() < 0) return;

        Vertex temp;
        if(a.getPosition().getZ() < b.getPosition().getZ()){
            temp = a;
            a = b;
            b = temp;
        }
        if(b.getPosition().getZ() < c.getPosition().getZ()){
            temp = b;
            b = c;
            c = temp;
        }
        if(a.getPosition().getZ() < b.getPosition().getZ()){
            temp = a;
            a = b;
            b = temp;
        }

        if(a.getPosition().getZ() < 0){
            return;
        }
        if(b.getPosition().getZ() < 0){
            double t = (0 - a.getPosition().getZ())/(b.getPosition().getZ() - a.getPosition().getZ());
            Vertex ab = a.mul(1-t).add(b.mul(t));
            double t2 = (0 - a.getPosition().getZ())/(c.getPosition().getZ() - a.getPosition().getZ());
            Vertex ac = a.mul(1-t2).add(c.mul(t2));

            rasterizer.rasterizeTriangle(a,ab,ac);
            return;
        }
        if(c.getPosition().getZ() < 0){
            double t = (0-b.getPosition().getZ())/(c.getPosition().getZ()-b.getPosition().getZ());
            Vertex bc = b.mul(1-t).add(c.mul(t));

            double t2 = (0-a.getPosition().getZ())/(c.getPosition().getZ()-a.getPosition().getZ());
            Vertex ac = a.mul(1-t2).add(c.mul(t2));

            rasterizer.rasterizeTriangle(a,b,bc);
            rasterizer.rasterizeTriangle(a,ac,bc);
            return;
        }
        rasterizer.rasterizeTriangle(a,b,c);
    }

    public void setProjection(Mat4 projection) {
        this.projection = projection;
    }

    public void setView(Mat4 view) {
        this.view = view;
    }
}
