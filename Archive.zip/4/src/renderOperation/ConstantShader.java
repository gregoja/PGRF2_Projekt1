package renderOperation;

import model.Vertex;
import transforms.Col;

public class ConstantShader implements Shader {
    @Override
    public Col getColor(Vertex v) {
        return new Col(1.,1.,0);
    }
}
