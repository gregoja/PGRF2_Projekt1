package model;

import transforms.Col;
import transforms.Mat4;
import transforms.Point3D;


public class Vertex implements Vectorable<Vertex>{
    private final Point3D position;
    private final Col color;

    public Vertex(Point3D position, Col color) {
        this.position = position;
        this.color = color;
    }

    public Point3D getPosition() {
        return position;
    }

    public Col getColor() {
        return color;
    }

    public Point3D transform(Mat4 transform){
        return position.mul(transform);
    }

    @Override
    public Vertex mul(double scalar) {
        return new Vertex(position.mul(scalar),color.mul(scalar));
    }

    @Override
    public Vertex add(Vertex vec) {
        return new Vertex(position.add(vec.getPosition()),color.add(vec.getColor()));
    }

    public Vertex dehomog(){
        return this.mul(1/this.getPosition().getW());
    }
    @Override
    public String toString() {
        return "Vertex{" +
                "position=" + position +
                ", color=" + color +
                '}';
    }
}