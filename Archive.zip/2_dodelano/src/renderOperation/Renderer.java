package renderOperation;

import model.Part;
import model.Solid;
import model.Vertex;
import transforms.Mat4;
import transforms.Point3D;

public class Renderer {
    private Mat4 view;
    private Mat4 projection;

    public void render(Solid solid){
        // TODO transformace
        for (Part part : solid.getPartBuffer()) {
            switch (part.getType()){
                case TRIANGLES: {
                    for(int i = 0; i < part.getCount(); i++){
                        int i1 = i*part.getStartIndex()+i*3;
                        int i2 = i1+1;
                        int i3 = i1+2;

                        int ii1 = solid.getIndexBuffer().get(i1);
                        int ii2 = solid.getIndexBuffer().get(i2);
                        int ii3 = solid.getIndexBuffer().get(i3);

                        /*Vertex a = solid.getVertexBuffer().get(ii1);
                        Vertex b = solid.getVertexBuffer().get(ii2);
                        Vertex c = solid.getVertexBuffer().get(ii3);    */

                        drawTriangle(solid.getVertexBuffer().get(ii1),solid.getVertexBuffer().get(ii2),
                                solid.getVertexBuffer().get(ii3));
                    }
                    break;
                }
            }
        }
    }

    private void drawTriangle(Vertex a, Vertex b, Vertex c){
        // M V P
        /*a = new Vertex(a.getPosition().mul(model).mul(view).mul(projection),a.getColor());
        b = new Vertex(b.getPosition().mul(model).mul(view).mul(projection),b.getColor());
        c = new Vertex(c.getPosition().mul(model).mul(view).mul(projection),c.getColor());*/

        Point3D pa = a.getPosition();Point3D pb = b.getPosition();Point3D pc = c.getPosition();
        if (pa.getX() > pa.getW() && pb.getX() > pb.getW() && pc.getX() > pc.getW()) return;
        if (-pa.getW() > pa.getX() && -pb.getW() > pb.getX() && -pc.getW() > pc.getX()) return;
        if (pa.getY() > pa.getW() && pb.getY() > pb.getW() && pc.getY() > pc.getW()) return;
        if (-pa.getW() > pa.getY() && -pb.getW() > pb.getY() && -pc.getW() > pc.getY()) return;
        if (pa.getZ() > pa.getW() && pb.getZ() > pb.getW() && pc.getZ() > pc.getW()) return;
        if (pa.getZ() < 0 && pb.getZ() < 0 && pc.getZ() < 0) return;

        // serazeni dle z. a.z>=b.z>=c.z
        // protože zkoukáme, jakým způsobem prochází trojúhelník přes plochu zNear;
        Vertex temp;
        if(a.getPosition().getZ() < b.getPosition().getZ()){
            temp = a;
            a = b;
            b = temp;
        }
        if(a.getPosition().getZ() < c.getPosition().getZ()){
            temp = a;
            a = b;
            b = temp;
        }
        if(a.getPosition().getZ() < c.getPosition().getZ()){
            temp = a;
            a = b;
            b = temp;
        }

        if(a.getPosition().getZ() < 0){
            return;
        }
        if(b.getPosition().getZ() < 0){
            // todo spocitat 2 body a raster traingle a d e
        }
        if(c.getPosition().getZ() < 0){
            // TODO spocitat 2 body a raster trangle(a,b,d) a (a,d,e)
        }




        //rasterizer.rasterTriangle(v1,v2,v3);
    }

    public Renderer(Mat4 view, Mat4 projection) {
        this.view = view;
        this.projection = projection;
    }
}
