package rasterOperation;

public class Visibility {
    // x,y,z
    // metoda clear
    // setValue, drawPixel(x,y,z,color)
    // TODO implementovat alg Zbuffer
}
